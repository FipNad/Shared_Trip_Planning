# Northbound

A shared road-trip planner for Bucharest ↔ Oulu or Levi. The `site/` folder is a static GitHub Pages website. The `worker/` folder is a Cloudflare Worker with a D1 database for shared edits, road routing and optional AI suggestions.

## What works

- Separate, ordered outbound and return stops, plus overnight counts and notes.
- Two maps side by side and one combined map with different route colours.
- Road kilometers for each leg and the combined trip. If road routing fails, the map shows dashed guide lines and **does not invent a distance**.
- Search for cities and places, reorder or remove stops, edit the destination, and propose, edit, plan or delete activities.
- A shared passphrase, with no individual accounts. All friends with the passphrase can edit the same D1 data. The page refreshes shared changes every 30 seconds while open.
- A local draft with starter routes and activities before the Worker is connected. Local drafts are saved only in that browser and are not automatically imported into D1.
- Optional AI suggestions using the OpenAI Responses API with a strict JSON schema. Suggestions are validated, deduplicated and saved as editable D1 activities; the Worker limits the group to three suggestion calls per UTC day.

The starter stops are examples, not a recommended driving schedule. The two routes may include the Tallinn–Helsinki ferry. Check ferries, winter driving, road closures, border requirements, hours and tickets separately.

## Run the website locally

From this directory:

```sh
python3 -m http.server 8000 --directory site
```

Open `http://localhost:8000`. This starts in local draft mode. You can also open `site/index.html` directly as a local file. Leaflet 1.9.4 is bundled under `site/vendor/leaflet/` with its license, so the map layout does not depend on a CDN stylesheet. OpenStreetMap tiles, Nominatim place search, and the public OSRM demo router still need an internet connection. Search is submitted only when someone clicks **Find stop** to avoid excessive Nominatim requests.

## Publish for your group

### 1. Deploy the shared backend

Create a free Cloudflare account and install or run [Wrangler](https://developers.cloudflare.com/workers/wrangler/install-and-update/). From `worker/`:

```sh
npx wrangler login
npx wrangler d1 create northbound-trip
cp wrangler.toml.example wrangler.toml
```

Put the D1 `database_id` printed by `d1 create` in `wrangler.toml`. Replace `YOUR_GITHUB_USERNAME` in `ALLOWED_ORIGIN` with your username. If you use a custom domain, add its origin as another comma-separated value. Then:

```sh
npx wrangler d1 migrations apply northbound-trip --remote
npx wrangler deploy
npx wrangler secret put TRIP_PASSPHRASE
```

Use a long, unique passphrase and share it privately with friends. `TRIP_PASSPHRASE` is never committed or placed in the webpage. The initial Worker deployment returns a configuration error for protected endpoints until this secret is set. Each `wrangler secret put` command deploys the new secret immediately. The `worker/wrangler.toml` file is ignored by Git because it contains your account's database ID.

**Recommended for route reliability:** create a free [openrouteservice](https://openrouteservice.org/) API key and add it as a Worker secret:

```sh
npx wrangler secret put ORS_API_KEY
```

Without it, the Worker uses the public OSRM demo router. This can be slow or unavailable and should not be relied on as a production SLA. Both providers return driving distance and road geometry; ferry-linked legs depend on their road graph. The Worker uses openrouteservice's current `api.heigit.org` endpoint.

**Optional AI suggestions:** add your OpenAI key as a Worker secret:

```sh
npx wrangler secret put OPENAI_API_KEY
```

OpenAI API usage is billed separately; free hosting does not make AI calls free. For predictable costs, create a dedicated OpenAI project and set a small monthly hard spend limit in its Limits settings. Do not put either API key in GitHub, browser storage, `site/`, or `wrangler.toml`. The default model is `gpt-4.1-mini`; change `OPENAI_MODEL` in `wrangler.toml` if you prefer another model that supports structured outputs. Redeploy after changing variables.

### 2. Publish the static page on GitHub Pages

Create a **public** GitHub repository for this folder, commit and push it to `main`. In the repository settings, enable **Pages → Build and deployment → GitHub Actions**. The included workflow publishes `site/` on every push to `main`.

Your site will be at `https://YOUR_GITHUB_USERNAME.github.io/REPOSITORY_NAME/` unless you configure a custom domain. GitHub Pages serves static files; the Cloudflare Worker is what makes shared edits and protected API calls possible.

### 3. Connect and invite friends

On the published site, click **Share & sync**. Enter the deployed `https://northbound-api.<your-subdomain>.workers.dev` URL and the trip passphrase. Send friends the site URL, Worker URL, and passphrase through your usual private channel. Each person can enter any display name. The passphrase is saved only in that browser tab's session storage; the Worker URL and display name are stored locally in the browser.

The app intentionally has one shared trip. Anyone with the passphrase can read and change all stops and activities. Rotate the Worker passphrase if it spreads beyond your group. Consider [Cloudflare Turnstile or rate limiting](https://developers.cloudflare.com/waf/rate-limiting-rules/) if you later share the page widely.

## Data and API structure

The first D1 migration seeds a sample plan and example activities. API endpoints are all under `/api`; except `/api/health`, they require the `X-Trip-Key` header. `GET /api/state` returns `{ config, stops, activities }`. Write endpoints are `PUT /api/config`, `POST /api/stops`, `PATCH/DELETE /api/stops/:id`, `PUT /api/stops/order`, `POST /api/activities`, `PATCH/DELETE /api/activities/:id`. Routing uses `POST /api/route` with `{ "coordinates": [[longitude, latitude], ...] }`. Suggestions use `POST /api/suggestions` with `{ "leg": "out" | "back" | "both" }`.

The AI request passes both ordered routes, named stops with IDs and coordinates, and existing ideas to the model. Its output schema is `{ ideas: [{ leg, stop_id, title, category, locality, description, source_url }] }`. The Worker checks each field and route ID before saving. An AI suggestion is only a planning lead; the app never treats an invented URL, opening hour, or booking as verified.

## Costs and limits

GitHub Pages can serve this static site from a public repository on GitHub Free. Cloudflare Workers and D1 have free quotas suitable for a small friend group, but limits can change and free quota exhaustion can pause requests. OpenAI calls are charged to your account. openrouteservice has a free key tier with request limits. Nominatim, OpenStreetMap tiles, and the OSRM demo service are public community services; keep use modest and use a dedicated provider if the group grows.

## Tests

Run `node --check site/app.js` and `node --check worker/src/index.js` for syntax checks. `node --test tests/*.test.mjs` exercises the Worker API with an in-memory D1 substitute and mocked routing/OpenAI responses; it does not spend API credit.
